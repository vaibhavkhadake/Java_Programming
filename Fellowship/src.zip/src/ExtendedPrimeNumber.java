
public class ExtendedPrimeNumber {

	public static void main(String[] args) 
	{
		

	}

}
