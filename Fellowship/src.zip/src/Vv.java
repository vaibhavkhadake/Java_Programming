import com.bridgelabzs.utility.Utility;

public class Vv {

	public static void main(String[] args) 
	{

		System.out.println("Enter amount");
		int amount=Utility.integerInput();
		
	}
	

}
