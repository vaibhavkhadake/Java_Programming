package com.bridgelabzs.datastructure;

public class Hashing<E> {
	
	public static void main(String[] args)
	{
		HashingUtility hl=new HashingUtility();
		Node[] array=new Node[10];
		hl.add(10);
		hl.display();
		
		

	}

}
