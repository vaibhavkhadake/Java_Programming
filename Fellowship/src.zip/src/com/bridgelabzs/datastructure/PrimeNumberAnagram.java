package com.bridgelabzs.datastructure;

public class PrimeNumberAnagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
