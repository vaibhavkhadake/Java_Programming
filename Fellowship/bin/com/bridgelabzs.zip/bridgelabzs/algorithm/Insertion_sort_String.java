/******************************************************************************
 *  
 *  Purpose: InsertionSort method for String.
 *  @author  Vaibhav P Khadake
 *  @version 1.0
 *  @since   23-08-2019
 *
 ******************************************************************************/
package com.bridgelabzs.algorithm;

import com.bridgelabzs.utility.Utility;

public class Insertion_sort_String {

	public static void main(String[] args)
	{
		String[] names= {"Vaibhav","Amit","Ajay","Rakesh","Suresh"};
		Utility.insetionString(names);
			
	
	}

}
