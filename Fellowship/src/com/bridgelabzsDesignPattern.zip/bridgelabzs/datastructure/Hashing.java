/******************************************************************************
 *  
 *  Purpose: Write a program to perform Hashing concepts.
 *  @author  Vaibhav P Khadake
 *  @version 1.0
 *  @since   3-09-2019
 *
 ******************************************************************************/
package com.bridgelabzs.datastructure;

public class Hashing<E> {
	
	public static void main(String[] args)
	{
		HashingUtility hl=new HashingUtility();
		Node[] array=new Node[10];
		hl.add(10);
		hl.display();
		
		

	}

}
