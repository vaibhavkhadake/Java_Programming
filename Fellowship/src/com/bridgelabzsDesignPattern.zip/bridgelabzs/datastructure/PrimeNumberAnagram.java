/******************************************************************************
 *  
 *  Purpose: check prime number is anagram or not.
 *  @author  Vaibhav P Khadake
 *  @version 1.0
 *  @since   03-09-2019
 *
 ******************************************************************************/
package com.bridgelabzs.datastructure;

public class PrimeNumberAnagram {

	public static void main(String[] args)
	{
		

	}

}
