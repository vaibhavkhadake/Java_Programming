/******************************************************************************
 *  
 *  Purpose: BubbleSort method for String.
 *  @author  Vaibhav P Khadake
 *  @version 1.0
 *  @since   22-08-2019
 *
 ******************************************************************************/
package com.bridgelabzs.algorithm;

import com.bridgelabzs.utility.Utility;

public class Bubble_sort_String {

	public static void main(String[] args) 
	{
		String[] s= {"vaibhav","amar","sandip","mark"};
		Utility.bubbleString(s);
	}

}
